# Session 2 — solutions

Open this folder in VS Code and run the files with Live Server, exactly like the template.

- `checkpoint_1_trial_types.html` : Exercise 1
- `checkpoint_2_randomization.html` : Exercise 2
- `checkpoint_3_feedback.html` : Exercise 3 (including the reaction time in the feedback)
- `checkpoint_4_blocks.html` : Exercise 4 (the full Session 2 experiment)
- `session2_challenge_solution.html` : the optional challenge (number of completed main trials in the closing message)
