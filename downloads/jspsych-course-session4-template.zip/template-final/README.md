# jsPsych Course Template — Session 4

Files:
- `experiment.html` — a minimal starter shell: jsPsych core + every
  plugin you might need already linked, an empty timeline. This is
  where you build your chosen task from scratch.
- `cheatsheet.md` — quick syntax reference for everything from
  Sessions 1–3 (trial shape, timeline variables, feedback, consent,
  participant ID, saving data, preloading, debrief, DataPipe). Open
  this alongside your editor while you work.
- `consent/` — the fuller external-html consent form from Session 3,
  if you'd rather use that instead of the simple Y/N version.
- `jspsych/` — jsPsych core and every plugin used across the whole
  course so far (`html-keyboard-response`, `survey-text`, `preload`,
  `external-html`). You likely won't need all of them for one task.

No task-specific starter code is provided — building the logic
yourself, from the specification and task description in the session
guide, is the point of today.

To get started: open this folder in VS Code and use Live Server on
`experiment.html`, same as every previous session.
