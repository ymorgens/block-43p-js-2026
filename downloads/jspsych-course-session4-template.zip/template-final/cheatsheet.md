# Session 4 Cheat Sheet

Quick syntax reference — everything here was built and explained in
Sessions 1–3. This is a reminder of *shape*, not a tutorial. If a
pattern doesn't make sense, check back in the relevant session's guide.

## Basic trial (Session 1, Part 4)

```js
const trial = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: "<p>Some HTML text</p>",
  choices: ["f", "j"]        // or "NO_KEYS", or omit for any key
};
```

## Timeline variables (Session 3, Part 1)

```js
const stimulus_trial = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: jsPsych.timelineVariable("html"),
  choices: ["f", "j"],
  data: {
    phase: "main",
    correct_response: jsPsych.timelineVariable("correct_response")
  },
  on_finish: function (data) {
    data.correct = (data.response === data.correct_response);
  }
};

const main_procedure = {
  timeline: [stimulus_trial],
  timeline_variables: stimulus_list,   // array of {html, correct_response, ...} objects
  randomize_order: true,
  repetitions: 3
};
```
Remember: a node like `main_procedure` goes into `timeline` directly — no `...`.
A plain array of individual trial objects needs `...` in front of it.

**Gotcha**: need to combine more than one timeline variable into a `stimulus: function() {...}`
(e.g. Stroop's word + color)? Inside the function, use `jsPsych.evaluateTimelineVariable("name")`,
NOT `jsPsych.timelineVariable("name")` — the latter gives you `[object Object]` instead of the
real value when used inside a function you write yourself. Outside a function (a direct
`stimulus:` value, or inside `data: {...}`), plain `jsPsych.timelineVariable()` is correct.
See session4.qmd's "Choosing a Task" section for the full explanation if this doesn't click.

## Feedback trial (Session 2, Part 3)

```js
const feedback_trial = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: function () {
    let last_trial_data = jsPsych.data.get().last(1).values()[0];
    return last_trial_data.correct
      ? "<p style='color:green;'>Correct!</p>"
      : "<p style='color:red;'>Incorrect.</p>";
  },
  choices: "NO_KEYS",
  trial_duration: 800
};
```

## Consent screen (Session 3, Part 3.0)

```js
const consent_trial = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: `
    <p>This is a short task for a course exercise. Responses are
    anonymous. Participation is voluntary.</p>
    <p>Press <b>Y</b> to agree and continue, or <b>N</b> to decline.</p>
  `,
  choices: ["y", "n"],
  on_finish: function (data) {
    if (data.response === "n") {
      jsPsych.abortExperiment("You chose not to continue. Thank you for your time.");
    }
  }
};
```
Want the fuller version instead? See `consent/informed_consent_en.html`
and the `external-html` plugin pattern from Session 3.

## Participant ID (Session 3, Part 3.1–3.2)

```js
const participant_info_trial = {
  type: jsPsychSurveyText,
  questions: [
    { prompt: "Please enter a participant ID:", name: "participant_id", required: true }
  ],
  on_finish: function (data) {
    jsPsych.data.addProperties({ participant_id: data.response.participant_id });
  }
};
```

## Saving data, with participant ID + timestamp (Session 3, Part 3.3 + Challenge B)

```js
let participant_id_value = "unknown";
// ... inside participant_info_trial's on_finish, also set:
// participant_id_value = data.response.participant_id;

function build_timestamp() {
  return new Date().toISOString().replace(/:/g, "-").replace(/\..+/, "");
}

const jsPsych = initJsPsych({
  on_finish: function () {
    let filename = participant_id_value + "_" + build_timestamp() + ".csv";
    jsPsych.data.get().localSave("csv", filename);
  }
});
```

**Only want the real stimulus-response rows** (no consent/instructions/fixation/feedback
rows) for Excel or SPSS? Save a second, filtered file (Session 3, Part 3.3.1) — filter by
`phase`, since only your actual stimulus trials set it:

```js
let responses_only = jsPsych.data.get().filter([{ phase: "practice" }, { phase: "main" }]);
responses_only.localSave("csv", participant_id_value + "_" + build_timestamp() + "_responses_only.csv");
```

## Preloading (Session 3, Part 2) — only if your task uses images

```js
let all_paths = [];
for (let i = 0; i < stimulus_list.length; i++) {
  all_paths.push(stimulus_list[i].image);
}

const preload_trial = {
  type: jsPsychPreload,
  images: all_paths
};
```

## Debrief with accuracy + RT (Session 3, Part 4)

```js
const debrief_trial = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: function () {
    let main_data = jsPsych.data.get().filter({ phase: "main" });
    let correct_data = main_data.filter({ correct: true });
    let accuracy = Math.round((correct_data.count() / main_data.count()) * 100);
    let mean_rt = Math.round(correct_data.select("rt").mean());
    return (
      "<p>Accuracy: " + accuracy + "%</p>" +
      "<p>Mean correct RT: " + mean_rt + "ms</p>" +
      "<p>Press any key to finish.</p>"
    );
  }
};
```

## `choices` values reference

| Value | Meaning |
|---|---|
| `["f", "j"]` | Only these keys end the trial |
| `"NO_KEYS"` | No key ends the trial (use with `trial_duration`) |
| omitted | Any key ends the trial |

## Device screening (Session 3, Bonus) — optional

```html
<script src="jspsych/plugin-browser-check.js"></script>
```
```js
const browser_check_trial = {
  type: jsPsychBrowserCheck,
  inclusion_function: (data) => data.mobile === false,
  exclusion_message: (data) => "<p>Please use a desktop or laptop computer.</p>"
};
```
Add as the very first item in your timeline, before consent.

## Going live: DataPipe (Session 4, "Going Live")

```html
<script src="https://unpkg.com/@jspsych-contrib/plugin-pipe"></script>
```
```js
const save_data_trial = {
  type: jsPsychPipe,
  action: "save",
  experiment_id: "YOUR_DATAPIPE_EXPERIMENT_ID",
  filename: participant_id_value + "_" + build_timestamp() + ".csv",
  data_string: () => jsPsych.data.get().csv()
};
```
Add this as the very last trial in your timeline once you're hosting on GitHub Pages.
