# Session 1 — solutions

Open the folder in VS Code and use Live Server, exactly like the template.

- `index.html`, `style.css`, `experiment.js` : Exercises 1 and 2 (compare with your own files)
- `exercise3_solution.html` : Exercise 3
- `challenge_solution.html` : the optional Part 4 challenge (welcome + fixation + coloured stimulus)
- Exercise 1 asks for a light-grey background (`lightgrey`); Exercise 2 step 4 asks for black. The CSS file shows the final (black) state.
