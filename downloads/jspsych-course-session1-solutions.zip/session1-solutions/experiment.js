/* ---------------------------------------------------
   experiment.js
   This file controls the BEHAVIOUR of index.html.
   Open your browser's console (F12, or right-click ->
   Inspect -> Console) to see the output of console.log().
   --------------------------------------------------- */


/* =====================================================
   PART 3 — JAVASCRIPT BASICS
   ===================================================== */

// --- 3.1 Variables ---
// A variable is a named "container" for a piece of information.
let participantID = 1;
let condition = "A";

console.log("Participant ID:", participantID);
console.log("Condition:", condition);


// --- 3.2 Arrays ---
// An array is an ordered list of values.
let stimuli = ["face1.jpg", "face2.jpg", "face3.jpg"];

console.log("First stimulus:", stimuli[0]); // arrays start counting at 0!
console.log("All stimuli:", stimuli);


// --- 3.3 Objects ---
// An object groups related information together under named keys.
let participant = {
  id: 1,
  condition: "A"
};

console.log("Participant object:", participant);
console.log("Participant's condition:", participant.condition);


// --- 3.4 If statements ---
// Runs some code only when a condition is true.
if (participant.condition === "A") {
  console.log("Running condition A");
} else {
  console.log("Running a different condition");
}


// --- 3.5 For loops ---
// Repeats a block of code multiple times.
for (let i = 0; i < stimuli.length; i++) {
  console.log("Stimulus " + i + ": " + stimuli[i]);
}


/* Try it yourself:
   1. Change the value of `condition` above and re-run (save + refresh).
      Watch how the output of the if-statement changes.
   2. Add a fourth image filename to the `stimuli` array
      and confirm the for loop now prints four lines.
*/


/* =====================================================
   EXERCISE 2 — IMAGE CAROUSEL (SOLUTION)
   ===================================================== */

// Steps 1 + 2: a fourth image (face4.jpg) was added and the order changed.
let carouselImages = ["face3.jpg", "face1.jpg", "face4.jpg", "face2.jpg"];

let currentIndex = 0;
let intervalTime = 2500; // Step 3: slower (was 1000 ms)

let carouselImage = document.querySelector("img");

// Show the first image straight away (otherwise the page would keep
// showing face1.jpg from index.html until the first interval fires).
carouselImage.src = "images/" + carouselImages[currentIndex];

function showNextImage() {
  currentIndex = currentIndex + 1;

  if (currentIndex >= carouselImages.length) {
    currentIndex = 0;
  }

  carouselImage.src = "images/" + carouselImages[currentIndex];
}

setInterval(showNextImage, intervalTime);

// Step 4 (black background) is done in style.css, not here.
