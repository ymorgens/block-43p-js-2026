# jsPsych Course Template — Session 1

Files:
- `index.html`   — the webpage used in Parts 1 and 2 (HTML/CSS)
- `style.css`    — appearance of index.html
- `experiment.js` — JavaScript basics + Exercise 2 (image carousel)
- `example_3.html` — minimal jsPsych experiment used in Part 4 / Exercise 3
- `images/`      — placeholder stimulus images (face1.jpg – face4.jpg)
- `jspsych/`     — the jsPsych library files (do not edit)

To get started: open this folder in VS Code, install the "Live Server"
extension, then right-click index.html or example_3.html and choose
"Open with Live Server".
