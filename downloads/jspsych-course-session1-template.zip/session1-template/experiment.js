/* ---------------------------------------------------
   experiment.js
   This file controls the BEHAVIOUR of index.html.
   Open your browser's console (F12, or right-click ->
   Inspect -> Console) to see the output of console.log().
   --------------------------------------------------- */


/* =====================================================
   PART 3 — JAVASCRIPT BASICS
   ===================================================== */

// --- 3.1 Variables ---
// A variable is a named "container" for a piece of information.
let participantID = 1;
let condition = "A";

console.log("Participant ID:", participantID);
console.log("Condition:", condition);


// --- 3.2 Arrays ---
// An array is an ordered list of values.
let stimuli = ["face1.jpg", "face2.jpg", "face3.jpg"];

console.log("First stimulus:", stimuli[0]); // arrays start counting at 0!
console.log("All stimuli:", stimuli);


// --- 3.3 Objects ---
// An object groups related information together under named keys.
let participant = {
  id: 1,
  condition: "A"
};

console.log("Participant object:", participant);
console.log("Participant's condition:", participant.condition);


// --- 3.4 If statements ---
// Runs some code only when a condition is true.
if (participant.condition === "A") {
  console.log("Running condition A");
} else {
  console.log("Running a different condition");
}


// --- 3.5 For loops ---
// Repeats a block of code multiple times.
for (let i = 0; i < stimuli.length; i++) {
  console.log("Stimulus " + i + ": " + stimuli[i]);
}


/* Try it yourself:
   1. Change the value of `condition` above and re-run (save + refresh).
      Watch how the output of the if-statement changes.
   2. Add a fourth image filename to the `stimuli` array
      and confirm the for loop now prints four lines.
*/


/* =====================================================
   EXERCISE 2 — IMAGE CAROUSEL (starter code)
   -----------------------------------------------------
   This code cycles through the images in `stimuli`,
   changing the <img> on the page every `intervalTime`
   milliseconds. Use this as your starting point.
   ===================================================== */

let carouselImages = ["face1.jpg", "face2.jpg", "face3.jpg"];
let currentIndex = 0;
let intervalTime = 1000; // milliseconds between images

// Find the <img> element already on the page (from index.html)
let carouselImage = document.querySelector("img");

function showNextImage() {
  currentIndex = currentIndex + 1;

  // loop back to the start once we reach the end of the array
  if (currentIndex >= carouselImages.length) {
    currentIndex = 0;
  }

  carouselImage.src = "images/" + carouselImages[currentIndex];
}

setInterval(showNextImage, intervalTime);

/* Try it yourself (Exercise 2):
   1. Add another image filename to `carouselImages`
      (there is a spare one at images/face4.jpg you can use).
   2. Change the order of the filenames in the array.
   3. Slow the carousel down by increasing `intervalTime`.
   4. Make the page background black by editing style.css.
*/
