# jsPsych Course Template — Session 2

Files:
- `experiment.html` — the file you will build up throughout today's session
  (starts with just an instructions trial + one example stimulus trial)
- `checkpoint_1_trial_types.html` — reference: end of Part 1
- `checkpoint_2_randomization.html` — reference: end of Part 2
- `checkpoint_3_feedback.html` — reference: end of Part 3
- `checkpoint_4_blocks.html` — reference: end of Part 4 (the full experiment)
- `images/` — circle/square stimuli (circle1–4.jpg, square1–4.jpg)
- `jspsych/` — the jsPsych library files, now including the
  `image-keyboard-response` plugin (do not edit)

The checkpoint files are reference material — try building each part
yourself in `experiment.html` first, and only check a checkpoint file if
you get stuck or want to compare your solution.

To get started: open this folder in VS Code and use Live Server on
`experiment.html`, same as Session 1.

Optional / bonus:
- `audio_video_demo.html` — audio-keyboard-response and video-keyboard-response,
  using the `media/` folder (a synthesized tone and a short generated clip —
  placeholders to swap for your own recordings). Requires Live Server (audio/video
  won't play reliably from a double-clicked file).
- `button_response_demo.html` — the same shape task, using on-screen buttons
  (`html-button-response`) instead of key presses.

See the "Bonus" sections near the end of the session guide for the explanations.
