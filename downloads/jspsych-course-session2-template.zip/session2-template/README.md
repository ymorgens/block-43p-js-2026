# jsPsych Course Template — Session 2

Files:
- `experiment.html` — the file you will build up throughout today's session
  (starts with just an instructions trial + one example stimulus trial)
- `images/` — circle/square stimuli (circle1–4.jpg, square1–4.jpg)
- `jspsych/` — the jsPsych library files, now including the
  `image-keyboard-response` plugin (do not edit)

Reference solutions for each exercise are posted on the course website
(Templates & Materials) the day after the practical.

To get started: open this folder in VS Code and use Live Server on
`experiment.html`, same as Session 1.

Optional / bonus:
- `audio_video_demo.html` — audio-keyboard-response and video-keyboard-response,
  using the `media/` folder (a synthesized tone and a short generated clip —
  placeholders to swap for your own recordings). Requires Live Server (audio/video
  won't play reliably from a double-clicked file).
- `button_response_demo.html` — the same shape task, using on-screen buttons
  (`html-button-response`) instead of key presses.

See the "Bonus" sections near the end of the session guide for the explanations.
