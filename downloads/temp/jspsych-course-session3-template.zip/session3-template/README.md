# jsPsych Course Template — Session 3

Files:
- `experiment.html` — your finished Session 2 experiment, unchanged. This
  is today's starting point — you'll keep extending this same file.
- `checkpoint_1_timeline_variables.html` — reference: end of Part 1
- `checkpoint_2_preload.html` — reference: end of Part 2
- `checkpoint_3_participant_data.html` — reference: end of Part 3
- `checkpoint_4_debrief.html` — reference: end of Part 4 (the full experiment)
- `images/` — same circle/square stimuli as Session 2
- `jspsych/` — jsPsych library files, now also including the `preload`
  and `survey-text` plugins (do not edit)

The checkpoint files are reference material — try building each part
yourself in `experiment.html` first, and only check a checkpoint file if
you get stuck or want to compare your solution.

To get started: open this folder in VS Code and use Live Server on
`experiment.html`, same as Sessions 1 and 2.

Note: `localSave()` (Part 3) downloads a CSV file to your own computer
when testing locally — this is just for today's practice. Session 4
covers how data gets saved when the experiment is actually running online.

Part 3 also adds a short consent screen before the participant ID
question — a simplified version of what a real study would need, but a
good habit to build now.

Optional / bonus: `consent/informed_consent_en.html` is a fuller,
realistic consent page (adapted for Erasmus University Rotterdam, with
placeholder researcher details), loaded via jsPsych's `external-html`
plugin. See `consent_external_demo.html` for a small working example,
and Part 3.0.1 of the session guide for the explanation. Replace the
placeholder logo and contact details before using this for a real study.

Also optional / bonus: `browser_check_demo.html` shows how to record
device/browser info and restrict participation to desktop/laptop
computers, using the `browser-check` plugin. See the "Bonus" section
of the session guide.

Two more optional / bonus demos:
- `adaptive_practice_demo.html` — a practice block that repeats itself
  automatically if accuracy is too low, using `loop_function`, plus a
  block that only appears if that happened, using `conditional_function`.
- `counterbalance_demo.html` — assigns participants to one of two
  condition orders based on their participant ID, so order is balanced
  across your whole sample rather than randomized per participant.
